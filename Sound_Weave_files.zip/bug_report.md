---
name: Bug Report
about: Report a bug to help us improve
title: '[BUG] '
labels: bug
assignees: ''

---

## Description
Brief description of the bug.

## Steps to Reproduce
1. 
2. 
3. 

## Expected Behavior
What should happen.

## Actual Behavior
What actually happens.

## Environment
- Node.js version:
- OS: 
- SoundWeave version:

## Logs
Any relevant error logs or output.

## Additional Context
Any other context about the problem.
