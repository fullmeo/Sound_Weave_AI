# Contributing to SoundWeave

Thank you for your interest in contributing! Here's how you can help.

## Getting Started

1. **Fork** the repository
2. **Clone** your fork
3. **Create** a feature branch: `git checkout -b feature/my-feature`
4. **Make** your changes
5. **Test** locally: `npm start`
6. **Commit**: `git commit -am 'Add feature'`
7. **Push**: `git push origin feature/my-feature`
8. **Create** a Pull Request

## Development Setup

```bash
# Install dependencies
npm install

# Create .env for testing
cp .env.example .env
# Add test REPLICATE_API_TOKEN

# Start development server
npm run dev

# Run linting
npm run lint

# Format code
npm run format
```

## Code Standards

- **Language**: JavaScript (ES Modules)
- **Node Version**: 18+
- **Style**: Consistent with existing code
- **Comments**: Document complex logic
- **Errors**: Meaningful error messages

## Commit Messages

- Use present tense: "Add feature" not "Added feature"
- Be descriptive: "Add rate limiting to API" not "Update code"
- Reference issues: "Fix #123"

## Pull Request Process

1. Update README.md with any new features
2. Add tests for new functionality
3. Ensure all tests pass: `npm test`
4. Lint your code: `npm run lint`
5. Provide clear PR description

## Areas for Contribution

- **Bug fixes**: Found a bug? Submit a PR!
- **Features**: New capabilities always welcome
- **Docs**: Improve documentation
- **Tests**: Add test coverage
- **Performance**: Optimize existing code
- **Security**: Report responsibly

## Feature Ideas

- Web UI dashboard
- MongoDB integration
- User authentication
- Advanced filtering
- Batch processing queue
- Custom model support

## Questions?

- Check [existing issues](https://github.com/fullmeo/SoundWeave/issues)
- Start a [discussion](https://github.com/fullmeo/SoundWeave/discussions)
- Read [documentation](./docs)

## Code of Conduct

- Be respectful and inclusive
- Welcome diverse perspectives
- Constructive feedback only
- No harassment or discrimination

---

Happy coding! 🎵
