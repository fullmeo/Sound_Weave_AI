# 🎵 SoundWeave

> **Production-ready music generation system** using Meta's MusicGen via Replicate API  
> REST API + CLI + Local Storage. Built for musicians, developers, and creators.

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Node.js](https://img.shields.io/badge/Node.js-18+-green)](https://nodejs.org)
[![Status](https://img.shields.io/badge/Status-Production%20Ready-brightgreen)](#)
[![PRs Welcome](https://img.shields.io/badge/PRs-welcome-brightgreen.svg)](#contributing)

<div align="center">

[Features](#features) • [Quick Start](#quick-start) • [API Docs](#api-documentation) • [CLI Usage](#cli-usage) • [Integration](#integration) • [Contributing](#contributing)

</div>

---

## 🎯 Why SoundWeave?

**Udio stopped allowing downloads** (Oct 2025). SoundWeave is the answer:

| Feature | Udio | SoundWeave |
|---------|------|-----------|
| Download | ❌ Disabled | ✅ Full control |
| Storage | ❌ Cloud-locked | ✅ Your server |
| Export | ❌ Restricted | ✅ WAV files |
| API | ❌ Limited | ✅ Complete REST + CLI |
| Integration | ❌ Difficult | ✅ Easy Node.js |
| Cost | ❌ Subscription | ✅ Pay-per-use |
| Privacy | ❌ Centralized | ✅ Self-hosted |

---

## ✨ Features

### 🎼 Music Generation
- **Text-to-Music**: Describe music, get WAV files
- **3 Model Sizes**: Small (30-45s), Medium (45-60s), Large (60-90s)
- **Flexible Duration**: 5-30 seconds per generation
- **Smart Validation**: Prompt length, duration constraints
- **Automatic Downloads**: Audio saved locally with metadata

### 🔌 Multiple Interfaces
- **REST API**: 8 production-grade endpoints
- **CLI Tool**: 6 commands for batch operations
- **Node.js SDK**: Direct service integration
- **JSON Storage**: Complete metadata tracking

### 🛡️ Production Quality
- **Rate Limiting**: 10 req/min (configurable)
- **Error Handling**: 6 error types with meaningful messages
- **Input Validation**: All endpoints protected
- **Security Headers**: Helmet enabled
- **Exponential Backoff**: Smart retry logic
- **Timeout Management**: 120s per generation

### 📊 Advanced Features
- **Pagination**: List with filtering
- **Statistics**: Storage & usage tracking
- **Health Checks**: Monitor system status
- **Batch Operations**: Generate multiple tracks
- **Metadata Indexing**: Complete generation history

---

## 🚀 Quick Start

### Prerequisites
- Node.js 18+
- Replicate API account (free at [replicate.com](https://replicate.com))

### Installation

```bash
# Clone repo
git clone https://github.com/fullmeo/SoundWeave.git
cd SoundWeave

# Install dependencies
npm install

# Configure
cp .env.example .env
# Edit .env and add REPLICATE_API_TOKEN
```

### Start Server

```bash
npm start
# Server on http://localhost:3000
```

### Generate Music (API)

```bash
curl -X POST http://localhost:3000/api/generate \
  -H "Content-Type: application/json" \
  -d '{
    "prompt": "uplifting orchestral music with strings",
    "duration": 15,
    "model": "large"
  }'
```

### Generate Music (CLI)

```bash
node cli/musicgen-cli.js generate \
  --prompt "lo-fi hip hop chill beats" \
  --duration 20 \
  --model large \
  --download
```

---

## 📚 API Documentation

### Endpoints

#### Generate Music
```http
POST /api/generate
Content-Type: application/json

{
  "prompt": "ambient electronic music",
  "duration": 15,
  "model": "large"
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "id": "550e8400-e29b-41d4-a716-446655440000",
    "status": "completed",
    "prompt": "ambient electronic music",
    "duration": 15,
    "audioUrl": "https://..."
  }
}
```

#### List Generations
```http
GET /api/generations?limit=20&offset=0
```

#### Get Generation
```http
GET /api/generations/:id
```

#### Download Audio
```http
GET /api/generations/:id/download
```

#### Delete Generation
```http
DELETE /api/generations/:id
```

#### Get Models
```http
GET /api/models
```

#### Get Statistics
```http
GET /api/stats
```

#### Health Check
```http
POST /api/health
```

**Full API docs:** See [API.md](./docs/API.md)

---

## 🖥️ CLI Usage

### Generate
```bash
node cli/musicgen-cli.js generate \
  --prompt "describe your music" \
  --duration 20 \
  --model large \
  --download
```

### List
```bash
node cli/musicgen-cli.js list --limit 15
```

### Get Details
```bash
node cli/musicgen-cli.js get <generation-id> --download
```

### Delete
```bash
node cli/musicgen-cli.js delete <generation-id>
```

### Statistics
```bash
node cli/musicgen-cli.js stats
```

### Show Models
```bash
node cli/musicgen-cli.js models
```

**Full CLI docs:** See [CLI.md](./docs/CLI.md)

---

## 🔗 Integration

### Direct Node.js Import

```javascript
import { MusicGenService } from './src/services/musicgen.service.js';
import { StorageService } from './src/services/storage.service.js';

const musicGen = new MusicGenService();
const storage = new StorageService();

const result = await musicGen.generate({
  prompt: 'ambient electronic music',
  duration: 20
});

await storage.saveMetadata(result);
const audioInfo = await storage.downloadAudio(result.id, result.audioUrl);
```

### REST API Integration

```javascript
const response = await fetch('http://localhost:3000/api/generate', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    prompt: 'uplifting orchestral music',
    duration: 15
  })
});

const data = await response.json();
```

### Integration Examples

- **Ut Queant Laxis**: Vocal analysis → music generation
- **NeuralMix**: Batch generation → DJ mixing
- **ButterFiles**: Auto-categorization → library management

**Integration guide:** See [INTEGRATION.md](./docs/INTEGRATION.md)

---

## ⚙️ Configuration

Environment variables (see `.env.example`):

```env
# API
REPLICATE_API_TOKEN=your_token_here
PORT=3000
HOST=0.0.0.0

# Generation
MAX_PROMPT_LENGTH=500
MAX_GENERATION_DURATION=30

# Rate Limiting
RATE_LIMIT_MAX_REQUESTS=10

# Logging
LOG_LEVEL=info

# Security
TRUST_PROXY=false
```

**Full config guide:** See [CONFIG.md](./docs/CONFIG.md)

---

## 📁 Project Structure

```
SoundWeave/
├── src/
│   ├── api/
│   │   └── routes.js              # 8 REST endpoints
│   ├── services/
│   │   ├── musicgen.service.js    # Replicate integration
│   │   └── storage.service.js     # File management
│   ├── utils/
│   │   └── validation.js          # Input validation
│   ├── config/
│   │   └── environment.js         # Configuration
│   └── index.js                   # Express server
├── cli/
│   └── musicgen-cli.js            # 6 CLI commands
├── docs/
│   ├── API.md
│   ├── CLI.md
│   ├── CONFIG.md
│   └── INTEGRATION.md
├── package.json
├── .env.example
└── README.md
```

---

## 🔒 Security

✅ **Implemented:**
- API keys server-side only
- Input validation all endpoints
- Rate limiting (10 req/min)
- Request timeouts (120s)
- Helmet security headers
- CORS restricted
- No eval() with user input
- Structured error responses

---

## 📊 Performance

### Generation Times (Replicate)
- Small model: 30-45 seconds
- Medium model: 45-60 seconds
- Large model: 60-90 seconds

### Storage
- Audio: ~2-3MB per 10 seconds
- Metadata: ~1KB per generation

### API
- Validation: <10ms
- List/Filter: <100ms
- Health check: <5ms

---

## 🤝 Contributing

We welcome contributions! Please see [CONTRIBUTING.md](./CONTRIBUTING.md)

```bash
# Fork repo
# Create feature branch
git checkout -b feature/my-feature

# Make changes
# Test locally
npm start

# Commit
git commit -am 'Add feature'

# Push & create PR
```

---

## 📝 License

MIT License - See [LICENSE](./LICENSE)

---

## 🐛 Issues & Support

- **Issues**: [GitHub Issues](https://github.com/fullmeo/SoundWeave/issues)
- **Discussions**: [GitHub Discussions](https://github.com/fullmeo/SoundWeave/discussions)
- **Docs**: [Full Documentation](./docs)

---

## 📦 Dependencies

- **Express.js** - HTTP server
- **Axios** - HTTP client (Replicate API)
- **Pino** - Structured logging
- **Helmet** - Security headers
- **express-rate-limit** - Rate limiting
- **Yargs** - CLI argument parsing

---

## 🎯 Roadmap

### Phase 2: Web UI
- [ ] React dashboard
- [ ] Real-time progress
- [ ] Audio player
- [ ] Batch controls

### Phase 3: Advanced Features
- [ ] Melody-guided generation
- [ ] Custom model training
- [ ] Genre templates
- [ ] Batch queue

### Phase 4: Integration
- [ ] MongoDB backend
- [ ] User accounts
- [ ] Usage analytics
- [ ] Advanced search

---

## 💡 Use Cases

- 🎸 **Musicians**: Generate background tracks
- 🎬 **Filmmakers**: Create royalty-free soundtracks
- 🎙️ **Podcasters**: Auto-generate intro/outro music
- 🎮 **Game Devs**: Generate game audio
- 🎨 **Content Creators**: Quick background music for videos

---

## 🙏 Credits

Built with:
- [Meta's MusicGen](https://github.com/facebookresearch/audiocraft)
- [Replicate API](https://replicate.com)
- [Express.js](https://expressjs.com)

---

<div align="center">

**[⬆ back to top](#soundweave)**

Made with 🎵 by Serigne  
[GitHub](https://github.com/fullmeo) • [Twitter](https://twitter.com/fullmeo)

</div>
